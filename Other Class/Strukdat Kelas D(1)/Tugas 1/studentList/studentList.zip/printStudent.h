void printStudent(Student t)
{
    printf("Name: %s Age: %d Gender: %c\n", t.name, t.age, t.gender);
} // end printStudent