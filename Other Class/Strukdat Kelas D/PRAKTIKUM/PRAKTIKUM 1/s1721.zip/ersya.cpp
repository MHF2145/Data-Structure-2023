#include <bits/stdc++.h>
using namespace std;

void showdq(deque<int> g)
{
    deque<int>::iterator it;
    for (it = g.begin(); it != g.end(); ++it)
        cout << " " << *it;
    cout << '\n';
}

int main()
{
    int t;
    cin >> t;

    while (t--)
    {
        deque<int> animeList;
        int x, y, n;
        cin >> x >> y >> n;

        for (int i = 0; i < x; i++)
        {
            int id;
            cin >> id;
            animeList.push_back(id);
        }

        if (n > x)
        {
            cout << "Kasian Ersya" << endl;
            break;
        }
        else
        {
            int count = 0;
            while (animeList.size() > 1)
            {
                for (int i = 0; i < y; i++)
                {
                    animeList.push_back(animeList.front());
                    animeList.pop_front();
                }
                animeList.pop_front();
                count++;

                if (count % n == 1)
                {
                    cout << animeList.front() << endl;
                }
            }
        }
    }
}
